//
// Created by Edumarek on 27/01/2022.
//

#include"plantas.hpp"

const int tamanho=5;

//------------------CONSTRUTORES&DESTRUTORES-------------------//

Planta::Planta(int top_X, int top_Y, int bot_X, int bot_Y){
  top_x=top_X;
  top_y=top_Y;
  bot_x=bot_X;
  bot_y=bot_Y;

  devorada();

  cor={0, 255, 0};
}

void Planta::desenhar_planta(SDL_Renderer* renderizador){
	SDL_Rect r;
	r.x=x;
	r.y=y;
	r.w=tamanho;
	r.h=tamanho;

	SDL_SetRenderDrawColor(renderizador, cor[0], cor[1], cor[2], 255);
	SDL_RenderDrawRect(renderizador, &r);
	SDL_RenderFillRect(renderizador, &r);
}

void Planta::devorada(){
  do{
    x=rand()%(bot_x-top_x)+top_x;
  }while(x%tamanho!=0);
  do{
    y=rand()%(bot_y-top_y)+top_y;
  }while(y%tamanho!=0);
}
