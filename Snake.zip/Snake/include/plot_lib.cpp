//
// Created by Edumarek on 27/01/2022.
//

#include"plantas.hpp"

const int tamanho=5;

//------------------CONSTRUTORES&DESTRUTORES-------------------//

Planta::Planta(int top_X, int top_Y, int bot_X, int bot_Y, int b){
  top_x=top_X;
  top_y=top_Y;
  bot_x=bot_X;
  bot_y=bot_Y;

  negativos=false;
  max_x=100;
  max_y=100;

  bordas=b;

  cor_dados={0, 255, 0};
  cor_linhas={255, 255, 255};

}

void Planta::desenhar_plot(SDL_Renderer* renderizador){
	SDL_Rect r;
	r.x=top_x;
	r.y=top_y;
	r.w=bot_x;
	r.h=bot_y;

	SDL_SetRenderDrawColor(renderizador, 0, 0, 0, 255);
	SDL_RenderDrawRect(renderizador, &r);
	SDL_RenderFillRect(renderizador, &r);

  r.x=top_x+bordas;
  r.y=top_y+bordas;
  r.w=bot_x-bordas;
  r.h=bot_y-bordas;

  SDL_SetRenderDrawColor(renderizador, cor_linhas[0], cor_linhas[1], cor_linhas[2], 255);
  SDL_RenderDrawRect(renderizador, &r);
  SDL_RenderFillRect(renderizador, &r);



}
