//
// Created by Edumarek on 27/01/2022.
//

#ifndef PLOT_LIB_HPP
#define PLOT_LIB_HPP
#include <iostream>
#include <vector>
#include <SDL2/SDL.h>
#include <cstdlib>

struct Plot{
    //posicao
    int top_x, top_y, bot_x, bot_y;
    //dados
    std::vector<float> dados;
    //config_grafico
    float max_x, max_y;
    bool negativos;
    std::vector<int> cor_dados;
    std::vector<int> cor_linhas;
    int bordas;

    Plot()=delete;
    Plot(int top_X, int top_Y, int bot_X, int bot_Y, int b);

    void desenhar_plot(SDL_Renderer* renderizador);
};

#endif //PLOT_LIB_HPP
