#include<iostream>
#include<cstdlib>
#include<vector>
#include<string>
#include"include/snake.hpp"
// #include"plot_lib.hpp"
#include<SDL2/SDL.h>
#include<SDL2/SDL_image.h>
#include<plantas.hpp>
#include<sstream>
#include <cmath>

#define WIDTH 300
#define HEIGHT 300
#define BORDA 5

#define gera_aleatorio populacao.emplace_back(new Snake(BORDA, BORDA, WIDTH-BORDA, HEIGHT-BORDA))
#define gera_planta comidas.emplace_back(new Planta(BORDA, BORDA, WIDTH-BORDA, HEIGHT-BORDA))

SDL_Window* janela=nullptr; //cria uma variavel do tipo Window
SDL_Renderer* renderizador=nullptr; //cria uma variavel do tipo renderizador

bool simulando=true, display_time=false, orgulho_vivo=false, player_vivo=false;
const int fps=30, tam_pop=300, max_ger=1500;
int steps=0, ger=0;
float melhor_score=-1;

void inicializacao_SDL();
void encerramento_SDL();

void update();
void input();
void draw();

void cenario();
void verifica_comer();
void verifica_colisao();

void gerar_nova_populacao();
void renasce();
int pool_selection(int max_score);
void salvar_tudo();

std::vector<Snake*> populacao;
std::vector<Snake*> backup_populacao;
std::vector<Planta*> comidas;
// Plot *grafico=new Plot((2*WIDTH)+BORDA, BORDA, (2*WIDTH)+BORDA+200, BORDA+200);

Snake* orgulho=new Snake(WIDTH+BORDA, BORDA, (2*WIDTH)-BORDA, HEIGHT-BORDA);
Planta* bife=new Planta(WIDTH+BORDA, BORDA, (2*WIDTH)-BORDA, HEIGHT-BORDA);

Snake* player=new Snake((WIDTH*2)+BORDA, BORDA, (3*WIDTH)-BORDA, HEIGHT-BORDA);
Planta* hamburguer=new Planta((WIDTH*2)+BORDA, BORDA, (3*WIDTH)-BORDA, HEIGHT-BORDA);

int main(int argc, char* argv[]){
	int fps_timer, delta_fps;

	inicializacao_SDL();

	for(int i=0; i<tam_pop; i++){
		gera_aleatorio;
		std::string t="saves/rede_neural_" + std::to_string(i) + ".txt";
		populacao[i]->cerebro->carregar_rede(t);
		gera_planta;
		comidas[i]->cor=populacao[i]->cor;
	}
	populacao.shrink_to_fit();
	comidas.shrink_to_fit();

	renasce();

	while(simulando && ger<=max_ger){
		fps_timer=SDL_GetTicks();

		update();
		input();
		draw();

		delta_fps=SDL_GetTicks()-fps_timer;
		if(1000/fps>delta_fps)
			SDL_Delay(1000/fps-delta_fps);
		if(steps%fps==0 && display_time)
			std::cout<<"Tempo de Simulacao: "<<steps/fps<<".0 s"<<std::endl;
	}
	encerramento_SDL();

	for(int i=0;i<(int)populacao.size();i++)
		delete populacao[i];
	for(int i=0;i<(int)backup_populacao.size();i++)
		delete backup_populacao[i];

	for(int i=0;i<(int)comidas.size();i++)
		delete comidas[i];

	delete orgulho;
	delete bife;
	delete player;
	delete hamburguer;

	return 0;
}

void inicializacao_SDL(){
	if(SDL_Init(SDL_INIT_EVERYTHING)<0)
		std::cout<<"Erro encontrado:  "<<SDL_GetError()<<std::endl;
	SDL_CreateWindowAndRenderer(WIDTH*3, HEIGHT, SDL_WINDOW_SHOWN, &janela, &renderizador);
	SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "2");
	SDL_SetWindowBordered(janela, SDL_TRUE);
	SDL_SetRenderDrawBlendMode(renderizador, SDL_BLENDMODE_BLEND);
	SDL_SetWindowTitle(janela, "Evolutionary Snake");
}

void encerramento_SDL(){
	SDL_DestroyWindow(janela);
	SDL_DestroyRenderer(renderizador);
	SDL_Quit();
}

void update(){
	steps++;

	if((int)populacao.size()<=0 && steps>0 && ger<=max_ger){
		steps=0;
		ger++;
		gerar_nova_populacao();
		system("rm saves/*.txt");
		salvar_tudo();
	}
}

void input(){
	SDL_Event evento;
		while(SDL_PollEvent(&evento)){
			if(evento.type == SDL_QUIT)
				simulando=false;
			if(evento.type == SDL_KEYDOWN && player_vivo){
				switch (evento.key.keysym.sym) {
					case SDLK_LEFT:
						if(player->direcao[0]!=1){
							player->direcao[0]=-1;
							player->direcao[1]=0;
						}
						break;
					case SDLK_RIGHT:
						if(player->direcao[0]!=-1){
							player->direcao[0]=1;
							player->direcao[1]=0;
						}
						break;
					case SDLK_UP:
						if(player->direcao[1]!=1){
							player->direcao[0]=0;
							player->direcao[1]=-1;
						}
						break;
					case SDLK_DOWN:
						if(player->direcao[1]!=-1){
							player->direcao[0]=0;
							player->direcao[1]=1;
						}
						break;
					default:
						break;
				}
			}
		}

	for(int i=0; i<(int)populacao.size(); i++){
		populacao[i]->movimentar(comidas[i]->x, comidas[i]->y);
		populacao[i]->vida-=10;
	}

	if(orgulho_vivo){
		orgulho->movimentar(bife->x, bife->y);
		orgulho->vida-=10;
	}

	if(player_vivo){
		player->x+=(player->direcao[0]*5);
		player->y+=(player->direcao[1]*5);

		player->corpo_x.insert(player->corpo_x.begin(), player->x);
		player->corpo_y.insert(player->corpo_y.begin(), player->y);
	}

	verifica_comer();
	verifica_colisao();
}

void draw(){
	//reset screen
	SDL_SetRenderDrawColor(renderizador, 0, 0, 0, 255);
	SDL_RenderClear(renderizador);
	//draw
	cenario();

	if(orgulho_vivo){
		orgulho->desenhar_Snake(renderizador);
		bife->desenhar_planta(renderizador);
	}

	if(player_vivo){
		player->desenhar_Snake(renderizador);
		hamburguer->desenhar_planta(renderizador);
	}

	for(int i=0; i<(int)populacao.size(); i++){
		populacao[i]->desenhar_Snake(renderizador);
		comidas[i]->desenhar_planta(renderizador);
	}

	// grafico->desenhar_plot();
	//comit draws
	SDL_RenderPresent(renderizador);
}

void cenario(){
	SDL_Rect bordaE, bordaI1, bordaI2, bordaI3;

	bordaE.x=0;
	bordaE.y=0;
	bordaE.w=(WIDTH*3	);
	bordaE.h=HEIGHT;

	bordaI1.x=BORDA;
	bordaI1.y=BORDA;
	bordaI1.w=WIDTH-(2*BORDA);
	bordaI1.h=HEIGHT-(2*BORDA);

	bordaI2.x=WIDTH+BORDA;
	bordaI2.y=BORDA;
	bordaI2.w=WIDTH-(2*BORDA);
	bordaI2.h=HEIGHT-(2*BORDA);

	bordaI3.x=(2*WIDTH)+BORDA;
	bordaI3.y=BORDA;
	bordaI3.w=WIDTH-(2*BORDA);
	bordaI3.h=HEIGHT-(2*BORDA);

	SDL_SetRenderDrawColor(renderizador, 255, 255, 255, 255);
	SDL_RenderDrawRect(renderizador, &bordaE);
	SDL_RenderFillRect(renderizador, &bordaE);

	SDL_SetRenderDrawColor(renderizador, 0, 0, 0, 255);
	SDL_RenderDrawRect(renderizador, &bordaI1);
	SDL_RenderFillRect(renderizador, &bordaI1);

	SDL_RenderDrawRect(renderizador, &bordaI2);
	SDL_RenderFillRect(renderizador, &bordaI2);

	SDL_RenderDrawRect(renderizador, &bordaI3);
	SDL_RenderFillRect(renderizador, &bordaI3);
}

void gerar_nova_populacao(){
	int max_score=-1, max_pos=0;

	while((int)populacao.size()>0){
		backup_populacao.emplace_back(new Snake(*populacao[0]));
		delete populacao[0];
		delete comidas[0];
		populacao.erase(populacao.begin());
		comidas.erase(comidas.begin());
	}

	for(int i=0;i<(int)backup_populacao.size();i++){
		backup_populacao[i]->cerebro->Calcular_Score(backup_populacao[i]->comprimento-5);
		if(backup_populacao[i]->cerebro->score>max_score){
			max_score=backup_populacao[i]->cerebro->score;
			max_pos=i;
		}
	}

	if(!orgulho_vivo){
		bife->devorada();
		if(max_score>melhor_score){
			melhor_score=max_score;
			delete orgulho;
			orgulho=new Snake(*backup_populacao[max_pos]);
			orgulho->top_x=WIDTH+BORDA;
			orgulho->top_y=BORDA;
			orgulho->bot_x=(2*WIDTH)-BORDA;
			orgulho->bot_y=HEIGHT-BORDA;
		}

		orgulho->x=(orgulho->bot_x+orgulho->top_x)/2;
		orgulho->y=(orgulho->bot_y+orgulho->top_y)/2;
		orgulho->comprimento=5;
		orgulho->vida=3000;
		bife->cor=orgulho->cor;
		orgulho_vivo=true;
	}

	if(!player_vivo)
		renasce();

	std::cout<<"Best Score = "<<melhor_score<<" | Best Score da geracao "<<ger<<" = "<<max_score<<std::endl;

	for(int i=0;i<tam_pop;i++){
		int a=pool_selection(max_score);
		int b=pool_selection(max_score);
		populacao.emplace_back(new Snake(*backup_populacao[a], *backup_populacao[b]));
	}

	for(int i=0;i<(int)backup_populacao.size();i++)
		delete backup_populacao[i];
	backup_populacao.clear();

	for(int i=0;i<tam_pop;i++){
		gera_planta;
		comidas[i]->cor=populacao[i]->cor;
	}
}

void renasce(){
	hamburguer->devorada();
	player->x=(player->bot_x+player->top_x)/2;
	player->y=(player->bot_y+player->top_y)/2;

	player->cor[0]=rand()%256;
	player->cor[1]=rand()%256;
	player->cor[2]=rand()%256;
	hamburguer->cor=player->cor;

	do{
		player->direcao[0]=rand()%3-1;
		player->direcao[1]=rand()%3-1;
	}while((player->direcao[0]==0 && player->direcao[1]==0) || (abs(player->direcao[0])==1 && abs(player->direcao[1])==1));

	player_vivo=true;

	player->corpo_x.clear();
	player->corpo_y.clear();
	player->corpo_x.push_back(player->x);
	player->corpo_y.push_back(player->y);
	player->comprimento=5;
	for(int i=1;i<player->comprimento;i++){
		player->corpo_x.push_back(player->corpo_x[i-1]+5);
		player->corpo_y.push_back(player->corpo_y[i-1]+5);
	}
}

int pool_selection(int max_score){
	int indice;
	while(true){
		indice=rand()%((int)backup_populacao.size());
		if(rand()%max_score<backup_populacao[indice]->cerebro->score)
			return indice;
	}
}

void verifica_comer(){
	for(int i=0;i<(int)populacao.size();i++)
		if(populacao[i]->x==comidas[i]->x && populacao[i]->y==comidas[i]->y){
			populacao[i]->comprimento++;
			populacao[i]->vida=3000;
			comidas[i]->devorada();
		}

	if((orgulho->x==bife->x && orgulho->y==bife->y) && orgulho_vivo){
		orgulho->comprimento++;
		orgulho->vida=3000;
		bife->devorada();
	}

	if((player->x==hamburguer->x && player->y==hamburguer->y) && player_vivo){
		player->comprimento++;
		hamburguer->devorada();
	}
}

void verifica_colisao(){
	for(int i=0;i<(int)populacao.size();i++){
		for(int j=1;j<populacao[i]->comprimento;j++)
			if(populacao[i]->x==populacao[i]->corpo_x[j] && populacao[i]->y==populacao[i]->corpo_y[j]){
				populacao[i]->vida=-1;
				break;
			}

		if(populacao[i]->x>=populacao[i]->bot_x || populacao[i]->x<populacao[i]->top_x || populacao[i]->y>=populacao[i]->bot_y || populacao[i]->y<populacao[i]->top_y || populacao[i]->vida<=0){
			backup_populacao.emplace_back(new Snake(*populacao[i]));
			delete populacao[i];
			delete comidas[i];
			populacao.erase(populacao.begin()+i);
			comidas.erase(comidas.begin()+i);
			i=0;
		}
	}

	for(int j=1;j<orgulho->comprimento;j++)
		if(orgulho->x==orgulho->corpo_x[j] && orgulho->y==orgulho->corpo_y[j]){
			orgulho->vida=-1;
			break;
		}

	if((orgulho->x>=orgulho->bot_x || orgulho->x<orgulho->top_x || orgulho->y>=orgulho->bot_y || orgulho->y<orgulho->top_y || orgulho->vida<=0) && orgulho_vivo)
		orgulho_vivo=false;

	for(int j=1;j<player->comprimento;j++)
		if(player->x==player->corpo_x[j] && player->y==player->corpo_y[j]){
			renasce();
			break;
		}


	if((player->x>=player->bot_x || player->x<player->top_x || player->y>=player->bot_y || player->y<player->top_y) && player_vivo)
		renasce();
}

void salvar_tudo(){
	for(int i=0;i<(int)populacao.size();i++){
		std::string t="saves/rede_neural_" + std::to_string(i) + ".txt";
		populacao[i]->cerebro->salvar_rede(t);
	}
}
