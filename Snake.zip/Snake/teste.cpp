#include<iostream>
#include<cstdlib>
#include<vector>
#include<SDL2/SDL.h>
#include<SDL2/SDL_image.h>


#define WIDTH 500
#define HEIGHT 500

SDL_Window* janela=nullptr; //cria uma variavel do tipo Window
SDL_Renderer* renderizador=nullptr; //cria uma variavel do tipo renderizador

bool simulando=true, display_time=false;
const int fps=30;
int steps=0;

void inicializacao_SDL();
void encerramento_SDL();

void update();
void input();
void draw();

int main(int argc, char* argv[]){
	int fps_timer, delta_fps;

	inicializacao_SDL();

	while(simulando && ger<=max_ger){
		fps_timer=SDL_GetTicks();

		update();
		input();
		draw();

		delta_fps=SDL_GetTicks()-fps_timer;
		if(1000/fps>delta_fps)
			SDL_Delay(1000/fps-delta_fps);
		if(steps%fps==0 && display_time)
			std::cout<<"Tempo de Simulacao: "<<steps/fps<<".0 s"<<std::endl;
	}
	encerramento_SDL();

	return 0;
}

void inicializacao_SDL(){
	if(SDL_Init(SDL_INIT_EVERYTHING)<0)
		std::cout<<"Erro encontrado:  "<<SDL_GetError()<<std::endl;
	SDL_CreateWindowAndRenderer(1360, HEIGHT, SDL_WINDOW_SHOWN, &janela, &renderizador);
	SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "2");
	SDL_SetWindowBordered(janela, SDL_TRUE);
	SDL_SetRenderDrawBlendMode(renderizador, SDL_BLENDMODE_BLEND);
	SDL_SetWindowTitle(janela, "Plot");
}

void encerramento_SDL(){
	SDL_DestroyWindow(janela);
	SDL_DestroyRenderer(renderizador);
	SDL_Quit();
}

void update(){
	steps++;


}

void input(){
	SDL_Event evento;
		while(SDL_PollEvent(&evento)){
			if(evento.type == SDL_QUIT)
				simulando=false;
		}
}

void draw(){
	//reset screen
	SDL_SetRenderDrawColor(renderizador, 0, 0, 0, 255);
	SDL_RenderClear(renderizador);
	//draw

	//comit draws
	SDL_RenderPresent(renderizador);
}
